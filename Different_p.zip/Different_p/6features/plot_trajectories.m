% function plot_trajectories(iter,cost,data_plot,n,T)
% plot_trajectories function plot the learning process
n=26;
T=6.2;
data_plot=load('data_plot_6features');
data_plot=struct2cell(data_plot);
data_plot=data_plot{1,1}

    figure(1);
    set(gcf,'Units','normalized','OuterPosition',[0.02 0.1 0.25 0.4]);
    set(0,'DefaultAxesFontName', 'Times New Roman');
    set(gcf,'PaperPositionMode','auto');
    set(gcf, 'Color', 'w');
%     %% upper level cost function
%     subplot(2,1,1);
%     plot(iter(2:end),cost(2:end),'b','linewidth',3);
%     hold on
%     xlabel('Number of iterations','FontName','Times New Roman','FontSize',16);
%     ylabel('$ \|E_{p( \bf r | \bf\theta)}[ \bf f]-\tilde{ \bf f} \|$','FontSize',16,'Interpreter','latex');
%     title('upper level cost function','FontName','Times New Roman','FontSize',16);
%     xlim([0 iter(end)+1]);
%     ylim([0 cost(2)+1]);
%     set(gca,'linewidth',1.5,'FontSize',16);
    %% trajectory
    start_x = data_plot(1,1)-5;
    end_x = data_plot(1,end)+10;
    figure(1);
%     subplot(2,1,2);
    ax(1) = plot(data_plot(1,:),data_plot(2,:),'r','linewidth',3);
    lgd = "demonstration";
    hold on
    s = size(data_plot);
    num_plot_line = s(1)/6 - 1;
    for k = 1:num_plot_line
        if k == num_plot_line
            ax(k+1) = plot(data_plot(6*k+1,:),data_plot(6*k+2,:),'Color',[0 0 1],'linewidth',3);
            ax(k+1).Color(4) = 0.6;
            hold on
            lgd(end+1) = ['final after ',num2str(n),' iteration'];
        else       
            ax(k+1) = plot(data_plot(6*k+1,:),data_plot(6*k+2,:),'--','Color',[1-0.2*k 1-0.2*k 1],'linewidth',3);
            hold on
            lgd(end+1) = ['after ',num2str((k-1)*10+1),' iteration'];
        end      
    end
    % lane information of highway
    plot([start_x end_x], [0 0], '-k', 'LineWidth', 1.5);
    hold on;
    plot([start_x end_x], [5.25 5.25], ':k','LineWidth', 1.5);
    hold on;
    plot([start_x end_x], [2*5.25 2*5.25], ':k', 'LineWidth', 1.5);
    hold on;
    plot([start_x end_x], [3*5.25 3*5.25], '-k', 'LineWidth', 1.5);
    hold on; 
    xlim([start_x end_x]);
    ylim([-1 5.25*3+1]);
    set(gca,'linewidth',1.5,'FontSize',16);
    xlabel('$x$(m)','FontName','Times New Roman','FontSize',16,'Interpreter','latex');
    ylabel('$y$(m)','FontName','Times New Roman','FontSize',16,'Interpreter','latex');
    title('trajectory of different iterations','FontName','Times New Roman','FontSize',16)
    legend(ax,lgd,'FontName','Times New Roman','FontSize',13,'FontWeight','normal','Location','northwest');
    %% x_velocity
    time_plot = 0:0.2:T;
    figure(2);
    set(gcf,'Units','normalized','OuterPosition',[0.02 0.1 0.25 0.4]);
    set(0,'DefaultAxesFontName', 'Times New Roman')
    set(gcf,'PaperPositionMode','auto')
    set(gcf, 'Color', 'w');
    set(gca,'linewidth',1.5,'FontSize',16);
    subplot(2,2,1);
    ax_vx(1) = plot(time_plot,data_plot(3,:),'r','linewidth',3);
    lgd_vx = "$v_x$ demonstration";
    hold on
    for k = 1:num_plot_line
        if k == num_plot_line
            ax_vx(k+1) = plot(time_plot,data_plot(6*k+3,:),'Color',[0 0 1],'linewidth',3);
            ax_vx(k+1).Color(4) = 0.6;
            hold on
            lgd_vx(end+1) = ['$v_x$ after ',num2str(n),' iteration'];
        else       
            ax_vx(k+1) = plot(time_plot,data_plot(6*k+3,:),'--','Color',[1-0.2*k 1-0.2*k 1],'linewidth',3);
            hold on
            lgd_vx(end+1) = ['$v_x$ after ',num2str((k-1)*10+1),' iteration'];
        end      
    end
    xlabel('time(s)','FontName','Times New Roman','FontSize',16);
    ylabel('$v_x$','FontName','Times New Roman','FontSize',20,'Interpreter','latex');
    title('x-direction velocity','FontName','Times New Roman','FontSize',16)
    legend(ax_vx,lgd_vx,'FontName','Times New Roman','FontSize',13,'FontWeight','normal','Location','southeast','Interpreter','latex');
    ylim([24 32]);
    xlim([0 6.4]);
    set(gca,'linewidth',1.5,'FontSize',16);
    %% y_velocity
    subplot(2,2,2);
    ax_vy(1) = plot(time_plot,data_plot(4,:),'r','linewidth',3);
    lgd_vy = "$v_y$ demonstration";
    hold on
    for k = 1:num_plot_line
        if k == num_plot_line
            ax_vy(k+1) = plot(time_plot,data_plot(6*k+4,:),'Color',[0 0 1],'linewidth',3);
            ax_vy(k+1).Color(4) = 0.6;
            hold on
            lgd_vy(end+1) = ['$v_y$ after ',num2str(n),' iteration'];
        else       
            ax_vy(k+1) = plot(time_plot,data_plot(6*k+4,:),'--','Color',[1-0.2*k 1-0.2*k 1],'linewidth',3);
            hold on
            lgd_vy(end+1) = ['$v_y$ after ',num2str((k-1)*10+1),' iteration'];
        end      
    end
    xlabel('time(s)','FontName','Times New Roman','FontSize',16);
    ylabel('$v_y$','FontName','Times New Roman','FontSize',20,'Interpreter','latex');
    title('y-direction velocity','FontName','Times New Roman','FontSize',16)
    legend(ax_vy,lgd_vy,'FontName','Times New Roman','FontSize',13,'FontWeight','normal','Location','northeast','Interpreter','latex');
    xlim([0 6.4]);
    set(gca,'linewidth',1.5,'FontSize',16);
    %% x_acceleration
    subplot(2,2,3);
    ax_ax(1) = plot(time_plot,data_plot(5,:),'r','linewidth',3);
    lgd_ax = "$a_x$ demonstration";
    hold on
    for k = 1:num_plot_line
        if k == num_plot_line
            ax_ax(k+1) = plot(time_plot,data_plot(6*k+5,:),'Color',[0 0 1],'linewidth',3);
            ax_ax(k+1).Color(4) = 0.6;
            hold on
            lgd_ax(end+1) = ['$a_x$ after ',num2str(n),' iteration'];
        else       
            ax_ax(k+1) = plot(time_plot,data_plot(6*k+5,:),'--','Color',[1-0.2*k 1-0.2*k 1],'linewidth',3);
            hold on
            lgd_ax(end+1) = ['$a_x$ after ',num2str((k-1)*10+1),' iteration'];
        end      
    end
    xlabel('time(s)','FontName','Times New Roman','FontSize',16);
    ylabel('$a_x$','FontName','Times New Roman','FontSize',20,'Interpreter','latex');
    title('x-direction acceleration','FontName','Times New Roman','FontSize',16)
    legend(ax_ax,lgd_ax,'FontName','Times New Roman','FontSize',13,'FontWeight','normal','Location','northeast','Interpreter','latex');
    xlim([0 6.4]);
    set(gca,'linewidth',1.5,'FontSize',16);
    %% y_acceleration
    subplot(2,2,4);
    ax_ay(1) = plot(time_plot,data_plot(6,:),'r','linewidth',3);
    lgd_ay = "$a_y$ of demonstration";
    hold on
    for k = 1:num_plot_line
        if k == num_plot_line
            ax_ay(k+1) = plot(time_plot,data_plot(6*k+6,:),'Color',[0 0 1],'linewidth',3);
            ax_ay(k+1).Color(4) = 0.6;
            hold on
            lgd_ay(end+1) = ['$a_y$ after ',num2str(n),' iteration'];
        else       
            ax_ay(k+1) = plot(time_plot,data_plot(6*k+6,:),'--','Color',[1-0.2*k 1-0.2*k 1],'linewidth',3);
            hold on
            lgd_ay(end+1) = ['$a_y$ after ',num2str((k-1)*10+1),' iteration'];
        end      
    end
    xlabel('time(s)','FontName','Times New Roman','FontSize',16);
    ylabel('$a_y$','FontName','Times New Roman','FontSize',20,'Interpreter','latex');
    title('y-direction acceleration','FontName','Times New Roman','FontSize',16)
    legend(ax_ay,lgd_ay,'FontName','Times New Roman','FontSize',13,'FontWeight','normal','Location','northeast','Interpreter','latex');
    xlim([0 6.4]); 
    set(gca,'linewidth',1.5,'FontSize',16);
% end

