clear all
close all
%% Load Positions information
%%% Car 1
car1=load('data_demo_ave\data_demo90.mat');
%%% Car 2
car2=load('data_demo_ave\state_environment90.mat');
%% Change struct to cell
%%% Car 1
Positions_car1_1=struct2cell(car1);
%%% Car 2
Positions_car2_1=struct2cell(car2);
%% Change cell to vector
%%% Car 1
PositionsCar1_1=Positions_car1_1{1};
%%% Car 2
PositionsCar2_1=Positions_car2_1{1};
%% Calculate average trajectories for each risk-parameters pair
%%% Car 1
Ave_PositionsCar1_1_x=PositionsCar1_1(2,2:32)';
Ave_PositionsCar1_1_y=PositionsCar1_1(3,2:32)';

%%% Car 2
Ave_PositionsCar2_1_x=PositionsCar2_1(1,2:32)';
Ave_PositionsCar2_1_y=PositionsCar2_1(2,2:32)';
%% Figures settings
fontsize_labels=16;
colors_vehicles=hsv(3);
w_lane=5.25;
l = 5;
b = 2;
x_count_start=50;
x_count_end=280;
figure(1)

%% plot average trajectories
subplot(2,1,1)
% plot road
plot([0 x_count_end],[0 0],'k-', 'LineWidth', 1.5)
hold on
plot([0 x_count_end],[w_lane w_lane],'k--', 'LineWidth',1.5)
hold on
plot([0 x_count_end],[2*w_lane 2*w_lane],'k--', 'LineWidth', 1.5)
hold on
plot([0 x_count_end],[3*w_lane 3*w_lane],'k-', 'LineWidth', 1.5)
hold on
% vehicles
xlabel('$x$(m)','interpreter','latex','FontSize',fontsize_labels);
ylabel('$y$(m)','interpreter','latex','FontSize',fontsize_labels);
title(sprintf('original trajectory'),'interpreter','latex','FontSize',fontsize_labels);
axis([x_count_start,x_count_end,-1,3*w_lane+1]);

length_position_x_1_car1=length(Ave_PositionsCar1_1_x);
p1(1) = plot(Ave_PositionsCar1_1_x,Ave_PositionsCar1_1_y,'r', 'LineWidth', 3);
hold on
p1(2) = plot(Ave_PositionsCar2_1_x,Ave_PositionsCar2_1_y,'b', 'LineWidth', 3);
hold on
for n=1:5:length_position_x_1_car1
    
     % Fill in the vehicle 2 with color blue
    x1_position=[Ave_PositionsCar2_1_x(n)-l/2,Ave_PositionsCar2_1_x(n)-l/2,Ave_PositionsCar2_1_x(n)+l/2,Ave_PositionsCar2_1_x(n)+l/2]; % The x_position of Car2
    y1_position=[Ave_PositionsCar2_1_y(n)-b/2,Ave_PositionsCar2_1_y(n)+b/2,Ave_PositionsCar2_1_y(n)+b/2,Ave_PositionsCar2_1_y(n)-b/2]; %The y_position of Car2
    color2=[(length_position_x_1_car1-n)/length_position_x_1_car1 (length_position_x_1_car1-n)/length_position_x_1_car1 1];% Set the color for Car2 
    vehicle2=patch(x1_position,y1_position,color2);  %Colour the Car2
    
    % Fill in the vehicle 1 with color red
    x1_position=[Ave_PositionsCar1_1_x(n)-l/2,Ave_PositionsCar1_1_x(n)-l/2,Ave_PositionsCar1_1_x(n)+l/2,Ave_PositionsCar1_1_x(n)+l/2]; % The x_position of Car1
    y1_position=[Ave_PositionsCar1_1_y(n)-b/2,Ave_PositionsCar1_1_y(n)+b/2,Ave_PositionsCar1_1_y(n)+b/2,Ave_PositionsCar1_1_y(n)-b/2]; %The y_position of Car1
    color1=[1 (length_position_x_1_car1-n)/length_position_x_1_car1 (length_position_x_1_car1-n)/length_position_x_1_car1];% Set the color for Car1 
    vehicle1=patch(x1_position,y1_position,color1);  %Colour the Car1
    
      % Frame of vehicle 2
    line([Ave_PositionsCar2_1_x(n)-l/2,Ave_PositionsCar2_1_x(n)-l/2],[Ave_PositionsCar2_1_y(n)+b/2,Ave_PositionsCar2_1_y(n)-b/2],'Color','b');
    line([Ave_PositionsCar2_1_x(n)-l/2,Ave_PositionsCar2_1_x(n)+l/2],[Ave_PositionsCar2_1_y(n)-b/2,Ave_PositionsCar2_1_y(n)-b/2],'Color','b');
    line([Ave_PositionsCar2_1_x(n)+l/2,Ave_PositionsCar2_1_x(n)+l/2],[Ave_PositionsCar2_1_y(n)-b/2,Ave_PositionsCar2_1_y(n)+b/2],'Color','b');
    line([Ave_PositionsCar2_1_x(n)+l/2,Ave_PositionsCar2_1_x(n)-l/2],[Ave_PositionsCar2_1_y(n)+b/2,Ave_PositionsCar2_1_y(n)+b/2],'Color','b');
    
    % Frame of vehicle 1
    line([Ave_PositionsCar1_1_x(n)-l/2,Ave_PositionsCar1_1_x(n)-l/2],[Ave_PositionsCar1_1_y(n)+b/2,Ave_PositionsCar1_1_y(n)-b/2],'Color','r');
    line([Ave_PositionsCar1_1_x(n)-l/2,Ave_PositionsCar1_1_x(n)+l/2],[Ave_PositionsCar1_1_y(n)-b/2,Ave_PositionsCar1_1_y(n)-b/2],'Color','r');
    line([Ave_PositionsCar1_1_x(n)+l/2,Ave_PositionsCar1_1_x(n)+l/2],[Ave_PositionsCar1_1_y(n)-b/2,Ave_PositionsCar1_1_y(n)+b/2],'Color','r');
    line([Ave_PositionsCar1_1_x(n)+l/2,Ave_PositionsCar1_1_x(n)-l/2],[Ave_PositionsCar1_1_y(n)+b/2,Ave_PositionsCar1_1_y(n)+b/2],'Color','r');
end
legend(p1,'EV trajectory ','TV trajectory','FontName','Times New Roman','FontSize',18,'FontWeight','normal','Location','southeast');
set(gca,'linewidth',1.5,'FontSize',15);
%% trajectory described by fifth order Polynomial 
data_demo = PositionsCar1_1(2:7,2:32);
state_environment = PositionsCar2_1(:,2:32);
time_interval = 2; % T=2s
frequency = 5; % f=5Hz 
[num_control_points,variables_start,variables_demo,time_end,n_trajectories] = manage_data(data_demo,time_interval,frequency);
ego_car = [];
for j = 1:n_trajectories 
    for i = 1:num_control_points
        if i == 1
        x0 = variables_start(6*(j-1)+1:2:6*(j-1)+5,1);
        y0 = variables_start(6*(j-1)+2:2:6*(j-1)+6,1);
        else
        x0 = variables_demo(6*(j-1)+1:2:6*(j-1)+5,i-1);
        y0 = variables_demo(6*(j-1)+2:2:6*(j-1)+6,i-1);
        end 
        xt = variables_demo(6*(j-1)+1:2:6*(j-1)+5,i);
        yt = variables_demo(6*(j-1)+2:2:6*(j-1)+6,i);
        x = [x0;xt];
        y = [y0;yt];

        if i == num_control_points
            T_end = time_end - time_interval*(num_control_points-1);
            gx = subtrajectory_coefficient(T_end,x);
            gy = subtrajectory_coefficient(T_end,y);
            [rx,ry,vx,vy,ax,ay,jx,jy] = subtrajectory_polynomial(gx,gy);
            for t_mpc = 0:0.2:T_end
                ego_car = [ego_car;rx(t_mpc) ry(t_mpc)];
            end
        else
            gx = subtrajectory_coefficient(time_interval,x);
            gy = subtrajectory_coefficient(time_interval,y);    
            [rx,ry,vx,vy,ax,ay,jx,jy] = subtrajectory_polynomial(gx,gy);
            for t_mpc = 0:0.2:time_interval-0.2
                ego_car = [ego_car;rx(t_mpc) ry(t_mpc)];
            end
        end
    end
end

subplot(2,1,2)
plot([0 x_count_end],[0 0],'k-', 'LineWidth', 1.5)
hold on
plot([0 x_count_end],[w_lane w_lane],'k--', 'LineWidth', 1.5)
hold on
plot([0 x_count_end],[2*w_lane 2*w_lane],'k--', 'LineWidth', 1.5)
hold on
plot([0 x_count_end],[3*w_lane 3*w_lane],'k-', 'LineWidth', 1.5)
hold on
p2(1) = plot(Ave_PositionsCar2_1_x,Ave_PositionsCar2_1_y,'b','LineWidth',5);
hold on
p2(2) = plot(Ave_PositionsCar1_1_x,Ave_PositionsCar1_1_y,'r','LineWidth',5);
hold on
p2(3) = plot(ego_car(:,1),ego_car(:,2),'--k','linewidth',3);
hold on
xlabel('$x$(m)','interpreter','latex','FontSize',fontsize_labels);
ylabel('$y$(m)','interpreter','latex','FontSize',fontsize_labels);
title(sprintf('TV and EV trajectories'),'interpreter','latex','FontSize',fontsize_labels);
legend(p2,'original TV trajectory ','original EV trajectory ','EV trajectory described by quintic polynomial','FontName','Times New Roman','FontSize',18,'FontWeight','normal','Location','southeast');
axis([x_count_start,x_count_end,-1,3*w_lane+1]);
set(gca,'linewidth',1.5,'FontSize',15);
%% trajectory explained by ellipse
target_car = state_environment(1:2,:)';
mpc = zeros(length(target_car(:,1)),1);
demo = zeros(length(target_car(:,1)),1);
for i=1:length(target_car(:,1))
   mpc(i) = (ego_car(i,2)-target_car(i,2)).^2/9 + (ego_car(i,1)-target_car(i,1)).^2/225;
   demo(i) = (data_demo(2,i)'-target_car(i,2)).^2/9 + (data_demo(1,i)'-target_car(i,1)).^2/225;
end
t_e=[0:0.1:2*pi];

figure(2)
set(gcf,'Units','normalized','OuterPosition',[0.02 0.1 0.25 0.4]);
set(0,'DefaultAxesFontName', 'Times New Roman')
set(0,'DefaultAxesFontSize', fontsize_labels)
set(gcf,'PaperPositionMode','auto')
set(gcf, 'Color', 'w');

subplot(2,1,1)
plot(ego_car(:,1),mpc,'Color',[1 0 0],'LineWidth',3);
xlabel('$x$(m)','interpreter','latex','FontSize',fontsize_labels);
ylabel('$s_e$','interpreter','latex','FontSize',20);
title(sprintf('scaling coefficient of ellipse $s_e$'),'interpreter','latex','FontSize',fontsize_labels);
axis([x_count_start,x_count_end,1,max(mpc)+0.5]);
hold on 
for step=1:15:31
    plot(ego_car(step,1),mpc(step),".",'Color',[0 0 0],'MarkerSize',30);
    hold on
end
set(gca,'linewidth',1.5,'FontSize',15);

subplot(2,1,2)
plot([0 x_count_end],[0 0],'k-', 'LineWidth', 1.5)
hold on
plot([0 x_count_end],[w_lane w_lane],'k--', 'LineWidth', 1.5)
hold on
plot([0 x_count_end],[2*w_lane 2*w_lane],'k--', 'LineWidth', 1.5)
hold on
plot([0 x_count_end],[3*w_lane 3*w_lane],'k-', 'LineWidth', 1.5)
hold on
p3(1) = plot(Ave_PositionsCar2_1_x,Ave_PositionsCar2_1_y,'b','LineWidth', 3);
hold on
p3(2) = plot(ego_car(:,1),ego_car(:,2),'r','linewidth',3);
hold on

for step=1:15:31
    length_data_plot=length(ego_car(:,1));
    % Fill in the target car with color blue
    xt_position=[target_car(step,1)-l/2,target_car(step,1)-l/2,target_car(step,1)+l/2,target_car(step,1)+l/2]; % The x_position of target car
    yt_position=[target_car(step,2)-b/2,target_car(step,2)+b/2,target_car(step,2)+b/2,target_car(step,2)-b/2]; % The y_position of target car
    color3=[(length_data_plot-step)/length_data_plot (length_data_plot-step)/length_data_plot 1];% Set the color for target car 
    vehicle3=patch(xt_position,yt_position,color3);  % Colour the target car
    
    % Fill in the ego car with color red
    xe_position=[ego_car(step,1)-l/2,ego_car(step,1)-l/2,ego_car(step,1)+l/2,ego_car(step,1)+l/2]; % The x_position of ego car 
    ye_position=[ego_car(step,2)-b/2,ego_car(step,2)+b/2,ego_car(step,2)+b/2,ego_car(step,2)-b/2]; % The y_position of ego car
    color4=[1 (length_data_plot-step)/length_data_plot (length_data_plot-step)/length_data_plot];% Set the color for ego car
    vehicle4=patch(xe_position,ye_position,color4);  % Colour the ego car
    
    % Frame of target car
    line([target_car(step,1)-l/2,target_car(step,1)-l/2],[target_car(step,2)+b/2,target_car(step,2)-b/2],'Color','b');
    line([target_car(step,1)-l/2,target_car(step,1)+l/2],[target_car(step,2)-b/2,target_car(step,2)-b/2],'Color','b');
    line([target_car(step,1)+l/2,target_car(step,1)+l/2],[target_car(step,2)-b/2,target_car(step,2)+b/2],'Color','b');
    line([target_car(step,1)+l/2,target_car(step,1)-l/2],[target_car(step,2)+b/2,target_car(step,2)+b/2],'Color','b');
    
    % Frame of ego car
    line([ego_car(step,1)-l/2,ego_car(step,1)-l/2],[ego_car(step,2)+b/2,ego_car(step,2)-b/2],'Color','r');
    line([ego_car(step,1)-l/2,ego_car(step,1)+l/2],[ego_car(step,2)-b/2,ego_car(step,2)-b/2],'Color','r');
    line([ego_car(step,1)+l/2,ego_car(step,1)+l/2],[ego_car(step,2)-b/2,ego_car(step,2)+b/2],'Color','r');
    line([ego_car(step,1)+l/2,ego_car(step,1)-l/2],[ego_car(step,2)+b/2,ego_car(step,2)+b/2],'Color','r');
    
    % plot ellipses
    ellipse1x=target_car(step,1)+15*cos(t_e);
    ellipse1y=target_car(step,2)+3*sin(t_e);
    p3(3) = plot(ellipse1x,ellipse1y,'-.','Color',[0.6 0.6 0.6]);
    hold on

    ellipse2x=target_car(step,1)+15*sqrt(mpc(step))*cos(t_e);
    ellipse2y=target_car(step,2)+3*sqrt(mpc(step))*sin(t_e);
    p3(4) = plot(ellipse2x,ellipse2y,'--','Color',[0 0 0]);
    hold on

    plot(ego_car(step,1),ego_car(step,2),".",'Color',[0 0 0],'MarkerSize',30);
    hold on
end
xlabel('$x$(m)','interpreter','latex','FontSize',fontsize_labels);
ylabel('$y$(m)','interpreter','latex','FontSize',fontsize_labels);
title(sprintf('trajectory with scaled ellipse'),'interpreter','latex','FontSize',fontsize_labels);
axis([x_count_start,x_count_end,-1,3*w_lane+1]);
legend(p3,'EV trajectory','TV trajectory','Safe Ellipse','Scaled Ellipse','FontName','Times New Roman','FontSize',fontsize_labels,'FontWeight','normal','Location','southeast');
set(gca,'linewidth',1.5,'FontSize',15);                      
