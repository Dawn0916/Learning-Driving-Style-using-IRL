function cost_function = cost_function(n,T,fq,environment,theta,start,conntrol_points,time_end,n_feature,v_des,s_e)
%cost_function provides the framework for the cost function that the IOC needs to learn

%%   initializtion
    f_theta = zeros(n_feature,1); % initialize column vector f_theta, all = 0
    target_car = environment(1:2,:)';
    ego_car = zeros(round(time_end*fq+1),2);
    ellipse = zeros(round(time_end*fq+1),1);
    distance = zeros(round(time_end*fq+1),1);
    i_begin = 0;
    i_end = 0;
    smpc_y = 0;
    a = 15;
    b = 3;
%%   calculate the feature values in cost function
    % select control points
    for i = 1:n
        if i == 1 
            cp_x0 = start(1:2:5,1);
            cp_y0 = start(2:2:6,1);
            smpc_begin = 0; 
            smpc_end = 0;
            smpc_active = 0;
        else
            cp_x0 = conntrol_points(1:2:5,i-1); % first control points used the start points
            cp_y0 = conntrol_points(2:2:6,i-1);
        end
        cp_xt = conntrol_points(1:2:5,i);       % following control points
        cp_yt = conntrol_points(2:2:6,i);

        if i == n % the end time is rounded
            T_end = time_end - T*(n-1); 
            % get coefficient 
            gx = subtrajectory_coefficient(T_end,[cp_x0;cp_xt]); 
            gy = subtrajectory_coefficient(T_end,[cp_y0;cp_yt]);
            % get polynomial
            [rx,ry,vx,vy,ax,ay,jx,jy] = subtrajectory_polynomial(gx,gy);
            for t_mpc = 0:0.2:T_end
                n_mpc = round((i-1)*10 + t_mpc*fq);
                ego_car(n_mpc+1,1) = rx(t_mpc);
                ego_car(n_mpc+1,2) = ry(t_mpc);
                % determine the t_acvive by patameter s_e
                ellipse(n_mpc+1) = (target_car(n_mpc+1,1)-ego_car(n_mpc+1,1)).^2/a.^2 + (target_car(n_mpc+1,2)-ego_car(n_mpc+1,2)).^2/b.^2;
                if ellipse(n_mpc+1) < s_e && smpc_active == 0 
                    smpc_begin = n_mpc+1;               % the recorded step that chance-constraint is active          
                    smpc_end = n_mpc+6;
                    smpc_y = ego_car(n_mpc+1,2);        % the y-position of the EV at the recorded step
                    smpc_active = 1;
                    i_begin = idivide(smpc_begin,int16(10))+1;
                    i_end = idivide(smpc_end,int16(10))+1;
                end 
            end
            % calculate feature values
            f_theta = feature_functions(f_theta,rx,ry,vx,vy,ax,ay,jx,jy,T_end,fq,environment,T*fq*(i-1)+1,v_des,i,smpc_active,smpc_begin,smpc_end,i_begin,i_end,smpc_y);
        else % normal time interval
            gx = subtrajectory_coefficient(T,[cp_x0;cp_xt]);
            gy = subtrajectory_coefficient(T,[cp_y0;cp_yt]);
            [rx,ry,vx,vy,ax,ay,jx,jy] = subtrajectory_polynomial(gx,gy);
            for t_mpc = 0:0.2:T-0.2
                n_mpc = round((i-1)*10 + t_mpc*fq);
                ego_car(n_mpc+1,1) = rx(t_mpc);
                ego_car(n_mpc+1,2) = ry(t_mpc);
                % determine the t_acvive by patameter s_e
                ellipse(n_mpc+1) = (target_car(n_mpc+1,1)-ego_car(n_mpc+1,1)).^2/a.^2 + (target_car(n_mpc+1,2)-ego_car(n_mpc+1,2)).^2/b.^2;
                if n_mpc >= 1
                    if ellipse(n_mpc+1) < s_e && smpc_active == 0 
                        smpc_begin = n_mpc+1 ;                       
                        smpc_end = n_mpc+6;
                        smpc_y = ego_car(n_mpc+1,2);
                        smpc_active = 1;
                        i_begin = idivide(smpc_begin,int16(10))+1;
                        i_end = idivide(smpc_end,int16(10))+1;
                    end
                end
            end
            % calculate feature values
            f_theta = feature_functions(f_theta,rx,ry,vx,vy,ax,ay,jx,jy,T,fq,environment,T*fq*(i-1)+1,v_des,i,smpc_active,smpc_begin,smpc_end,i_begin,i_end,smpc_y);
        end
    end
%% the value of cost function
    cost_function = (theta')*f_theta;
end


