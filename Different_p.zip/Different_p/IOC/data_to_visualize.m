function data_plot = data_to_visualize(time_interval,frequency,control_points,num_control_points,time_end)
%data_to_visualiz function convert and record the data needed for plot

%% initialization  
    x_plot = [];
    y_plot = [];
    vx_plot = [];
    vy_plot = [];
    ax_plot = [];
    ay_plot = [];
%% calculate x,y,v_x,v_y,a_x,a_y
    for i = 1:num_control_points
        if i == num_control_points % the end time is rounded
            T_end = time_end - time_interval*(num_control_points-1);
            gx = subtrajectory_coefficient(T_end,[control_points(1:2:5,i);control_points(1:2:5,i+1)]);
            gy = subtrajectory_coefficient(T_end,[control_points(2:2:6,i);control_points(2:2:6,i+1)]);
            [rx,ry,vx,vy,ax,ay,jx,jy] = subtrajectory_polynomial(gx,gy);
            t_plot = 0:1/frequency:T_end;
            x_plot = [x_plot rx(t_plot)];   % postion
            y_plot = [y_plot ry(t_plot)];
            vx_plot = [vx_plot vx(t_plot)]; % velocity
            vy_plot = [vy_plot vy(t_plot)];
            ax_plot = [ax_plot ax(t_plot)]; % acceleration
            ay_plot = [ay_plot ay(t_plot)];
        else % normal time interval
            gx = subtrajectory_coefficient(time_interval,[control_points(1:2:5,i);control_points(1:2:5,i+1)]);
            gy = subtrajectory_coefficient(time_interval,[control_points(2:2:6,i);control_points(2:2:6,i+1)]);
            [rx,ry,vx,vy,ax,ay,jx,jy] = subtrajectory_polynomial(gx,gy);
            t_plot = 0:1/frequency:time_interval-0.2;
            x_plot = [x_plot rx(t_plot)];
            y_plot = [y_plot ry(t_plot)];
            vx_plot = [vx_plot vx(t_plot)];
            vy_plot = [vy_plot vy(t_plot)];
            ax_plot = [ax_plot ax(t_plot)];
            ay_plot = [ay_plot ay(t_plot)];
        end
    end
    data_plot = [x_plot;y_plot;vx_plot;vy_plot;ax_plot;ay_plot];
end