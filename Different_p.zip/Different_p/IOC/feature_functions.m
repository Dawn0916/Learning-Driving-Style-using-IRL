function f = feature_functions(f, rx,ry,vx,vy,ax,ay,jx,jy,T,fq,environment,n0,v_des,i,smpc_active,smpc_begin,smpc_end,i_begin,i_end,smpc_y)
%feature_functions define the features we select and use for IOC

%% feature calculation
    % 1.feature:Acceleration
    func_fa = @(x) ax(x).^2 ;
    f(1) = f(1) + integral(func_fa,0,T);
    
    % 2.feature:Normal Acceleration
    func_fan = @(x) ay(x).^2;
    f(2) = f(2) + integral(func_fan,0,T);

    % 3.feature: Desired Speed
    func_fv = @(x) abs(v_des - vx(x));
    f(3) = f(3) + integral(func_fv,0,T);

    % 4.feature: Desired Lane
    lane = 7.875;
    func_fl3 = @(x) abs(lane-ry(x));
    f(4) = f(4) + integral(func_fl3,0,T,'ArrayValued',true);

    % 5.feature: Starting Lane
    if i == 1 
        func_fbegin = @(x) 10*abs(ry(x)-2.625);
        f(5) = f(5) + integral(func_fbegin,0,0.5,'ArrayValued',true);
    end

    % 6.feature: End Lane
    if i == 3
        func_fend = @(x) 10*abs(ry(x)-7.875);
        f(6) = f(6) + integral(func_fend,T-1,T,'ArrayValued',true);
    end

    % 7.feature: Collision Avoidance
    oc_x = @(x) environment(1,n0) + environment(4,1)*x;
    oc_y = environment(2,1); % constant
    func_fd = @(x) v_des./abs(rx(x)-oc_x(x));
    f(7) = f(7) + integral(func_fd,0,T); 

    % smpc feature
    if smpc_active == 1 && i == i_begin
        T_begin = 0.1*(mod(smpc_begin,10))*T;
        f(8) = 10*exp(-abs(ry(T_begin)-oc_y)); 
    elseif smpc_active == 0
        f(8) = 1e6;
    end

    if smpc_active == 1 && i == i_end
        T_end = 0.1*(mod(smpc_end,10))*T;
        f(9) = 10*exp(-abs(ry(T_end)-oc_y));
    elseif smpc_active == 0
        f(9) = 1e6;
    end

    % position in the SMPC active time interval
    func_fsl = @(x) 10*abs(ry(x) - smpc_y);
    if i_begin == i_end && smpc_active == 1 && i_begin == i
        f(10) = f(10)+ integral(func_fsl,T_begin,T_end,'ArrayValued',true);
    elseif i_begin ~= i_end && smpc_active == 1
        if i == i_begin
            f(10) = f(10) + integral(func_fsl,T_begin,T,'ArrayValued',true);
        elseif i == i_end
            f(10) = f(10) + integral(func_fsl,0,T_end,'ArrayValued',true);
        end
    end
end