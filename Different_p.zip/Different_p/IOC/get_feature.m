function feature = get_feature(n,T,fq,environment,start,control_points,time_end,n_traj,n_feature,v_des,s_e)
%get_feature function is used to calculate the empirical feature and the approximated expected feature

%%   initializtion
    feature = zeros(n_feature,n_traj); % initialize column vector f_theta, all = 0
    target_car = environment(1:2,:)';
    ego_car = zeros(round(time_end*fq+1),2);
    ellipse = zeros(round(time_end*fq+1),1);
    i_begin = 0;
    i_end = 0;
    smpc_y = 5.25;
    a = 15;
    b = 3;
%%   calculate the feature values in cost function
    % select control points
    for j = 1:n_traj    
        for i = 1:n
            if i == 1
                x0 = start(6*(j-1)+1:2:6*(j-1)+5,1);
                y0 = start(6*(j-1)+2:2:6*(j-1)+6,1);              
                smpc_begin = 0; 
                smpc_end = 0;
                smpc_active = 0; 
            else
                x0 = control_points(6*(j-1)+1:2:6*(j-1)+5,i-1); % first control points used the start points
                y0 = control_points(6*(j-1)+2:2:6*(j-1)+6,i-1);
            end           
            xt = control_points(6*(j-1)+1:2:6*(j-1)+5,i);       % following control points
            yt = control_points(6*(j-1)+2:2:6*(j-1)+6,i);        
            x = [x0;xt];
            y = [y0;yt];
            if i == n % the end time is rounded
                T_end = time_end - T*(n-1);
                % get coefficient
                gx = subtrajectory_coefficient(T_end,x);
                gy = subtrajectory_coefficient(T_end,y);
                % get polynomial
                [rx,ry,vx,vy,ax,ay,jx,jy] = subtrajectory_polynomial(gx,gy);
                for t_mpc = 0:0.2:T_end
                    n_mpc = round((i-1)*10 + t_mpc*fq);
                    ego_car(n_mpc+1,1) = rx(t_mpc);
                    ego_car(n_mpc+1,2) = ry(t_mpc);
                    % determine the t_acvive by patameter s_e
                    ellipse(n_mpc+1) = (target_car(n_mpc+1,1)-ego_car(n_mpc+1,1)).^2/a.^2 + (target_car(n_mpc+1,2)-ego_car(n_mpc+1,2)).^2/b.^2;
                    if ellipse(n_mpc+1) < s_e && smpc_active == 0 
                        smpc_begin = n_mpc+1;                       % the recorded step that chance-constraint is active                        
                        smpc_end = n_mpc+6;
                        smpc_y = ego_car(n_mpc,2);                  % the y-position of the EV at the recorded step
                        smpc_active = 1;
                        i_begin = idivide(smpc_begin,int16(10))+1;
                        i_end = idivide(smpc_end,int16(10))+1;
                    end 
                end
                % calculate feature values
                feature(:,j) = feature_functions(feature(:,j),rx,ry,vx,vy,ax,ay,jx,jy,T_end,fq,environment,T*fq*(i-1)+1,v_des,i,smpc_active,smpc_begin,smpc_end,i_begin,i_end,smpc_y);
            else% normal time interval
                gx = subtrajectory_coefficient(T,x);
                gy = subtrajectory_coefficient(T,y);    
                [rx,ry,vx,vy,ax,ay,jx,jy] = subtrajectory_polynomial(gx,gy);
                for t_mpc = 0:0.2:T-0.2
                    n_mpc = round((i-1)*10 + t_mpc*fq);
                    ego_car(n_mpc+1,1) = rx(t_mpc);
                    ego_car(n_mpc+1,2) = ry(t_mpc);
                    % determine the t_acvive by patameter s_e
                    ellipse(n_mpc+1) = (target_car(n_mpc+1,1)-ego_car(n_mpc+1,1)).^2/a.^2 + (target_car(n_mpc+1,2)-ego_car(n_mpc+1,2)).^2/b.^2;                   
                    if n_mpc >= 1 
                        if ellipse(n_mpc+1) < s_e && smpc_active == 0
                            smpc_begin = n_mpc+1;                       
                            smpc_end = n_mpc+6;
                            smpc_y = ego_car(n_mpc+1,2);
                            smpc_active = 1;
                            i_begin = idivide(smpc_begin,int16(10))+1;
                            i_end = idivide(smpc_end,int16(10))+1;
                        end 
                    end
                end
                % calculate feature values
                feature(:,j) = feature_functions(feature(:,j),rx,ry,vx,vy,ax,ay,jx,jy,T,fq,environment,T*fq*(i-1)+1,v_des,i,smpc_active,smpc_begin,smpc_end,i_begin,i_end,smpc_y); 
            end
        end
    end
    feature = mean(feature,2);
end

