function [num_control_points,variables_start,variables_demo,time_end,n_traj] = manage_data(data_demo,time_interval,frequency)
%manage_data function calculate some needed parameter for IOC

    sz = size(data_demo);
    num_control_points = round(sz(2)/(time_interval*frequency));    % number of control points
    variables_start = data_demo(:,1);                               % start of trajectory
    variables_demo = [];                                            % control points of the demonstration
    n_traj = round(sz(1)/6);                                        % number of the sub-trajectory
    for i = 1:num_control_points
        if i == num_control_points
            variables_demo = [variables_demo data_demo(:,end)];
            time_end = (sz(2)-1)*0.2;                               % rounded end time
        else
            variables_demo = [variables_demo data_demo(:,i*time_interval*frequency+1)];
        end
    end
end



    