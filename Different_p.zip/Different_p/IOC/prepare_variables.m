function variables_init = prepare_variables(num_control_points,variables_start,state_environment,time_interval,frequency,n_traj)
%prepare_variables function initialize the control points for the lower level program

    % the start point is same as demonstration
    variables_pre = [variables_start zeros(6*n_traj,num_control_points)]; 

    for j = 1:n_traj
        for i = 1:num_control_points
            variables_pre(6*(j-1)+1,i+1) = variables_pre(6*(j-1)+1,i) + time_interval*variables_pre(6*(j-1)+3,i);
            if i == 1
                variables_pre(6*(j-1)+2,i+1) = 2.625;   % the first control point is initialized on the start lane 
                variables_pre(6*(j-1)+3,i+1) = 30;      % the speed is initialized as the desired speed of the desired lane
            else
                variables_pre(6*(j-1)+2,i+1) = 7.875;   % the rest control points are initialized on the desired lane 
                variables_pre(6*(j-1)+3,i+1) = 30;      % the speed is initialized as the desired speed of the desired lane
            end
        end
    end
    variables_init = variables_pre(:,2:end);
end

