function [rx,ry,vx,vy,ax,ay,jx,jy] = subtrajectory_polynomial(gx,gy)
%subtrajectory_polynomial function provide the polynomial of the position, velocity, acceleration and jerk of the trajectory

    rx = @(x) gx(1)+gx(2)*x+gx(3)*x.^2+gx(4)*x.^3+gx(5)*x.^4+gx(6)*x.^5;    % x-position
    ry = @(x) gy(1)+gy(2)*x+gy(3)*x.^2+gy(4)*x.^3+gy(5)*x.^4+gy(6)*x.^5;    % y-position
    
    vx = @(x) gx(2)+2*gx(3)*x+3*gx(4)*x.^2+4*gx(5)*x.^3+5*gx(6)*x.^4;       % x-velocity
    vy = @(x) gy(2)+2*gy(3)*x+3*gy(4)*x.^2+4*gy(5)*x.^3+5*gy(6)*x.^4;       % y-velocity
    
    ax = @(x) 2*gx(3)+6*gx(4)*x+12*gx(5)*x.^2+20*gx(6)*x.^3;                % x-acceleration
    ay = @(x) 2*gy(3)+6*gy(4)*x+12*gy(5)*x.^2+20*gy(6)*x.^3;                % y-acceleration
    
    jx = @(x) 6*gx(4)+24*gx(5)*x+60*gx(6)*x.^2;                             % x-jerk
    jy = @(x) 6*gy(4)+24*gy(5)*x+60*gy(6)*x.^2;                             % y-jerk
end