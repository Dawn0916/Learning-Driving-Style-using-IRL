%main.m：set risk_parameter and generate the trajectory from SMPC, then do IOC and show the results
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%SMPC folder：Code from Ni Dang
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%Functions with changes:
# SMPC function is the original main function and the initial states of two vehicles are changes

#matrix Q, R, S in:
chance_constraints
chance_constraints_p
runningcosts
runningcosts_RefChange
terminalcosts
terminalcosts_RefChange

#constraint delta, psi in:
constraints
constraints_p
linearconstraints
terminalconstraints
terminalconstraints_p

#Sum_w in chance_constraints is set to constant.

%%New function: 
#convert_data: transform the states and iuputs to the form of [r_x, r_y, v_x, v_y ,a_x, a_y] for IOC.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%IOC folder：Inverse optimal control algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Function: IOC.m 						is main algorithm for Inverse optimal control
Function: cost_function.m 				provides the framework for the cost function that the IOC needs to learn
Function: data_to_visualiz.m 				convert and record the data needed for plot
Function: feature_functions.m 				define the features we select and use for IOC
Function: get_feature.m					is used to calculate the empirical feature and the approximated expected feature
Function: manage_data.m 				calculate some needed parameter for IOC
Function: plot_trajectories.m 				plot the learning process
Function: prepare_variables.m				initialize the control points for the lower level program
Function: subtrajectory_coefficient.m 			calculate the coefficients of the 5th order polynomial
Function: subtrajectory_polynomial 			provide the polynomial of the position, velocity, acceleration and jerk of the trajectory
PlotAverageTrajectories.m				plot the original trajectory generated from SMPC
Folder: data_demo						Store individual trajectories
Folder: data_demo_ave					Store average trajectories from 10 demonstrations
Folder: result						Store results under different risk_parameter