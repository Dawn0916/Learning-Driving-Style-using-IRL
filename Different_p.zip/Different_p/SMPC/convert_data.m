function convert_data(states_vehicles,control_vehicles,rp)
%convert_data function transforms the states and iuputs to the form of [r_x, r_y, v_x, v_y ,a_x, a_y]

    lr = 2;
    lf = 2;
    
    stats_demo = states_vehicles{2}(1:end-1,:);   
    a_demo = control_vehicles{2}(3:2:end-1,1);
    delta_demo = control_vehicles{2}(4:2:end,1);
    
    rx = stats_demo(:,1);
    ry = stats_demo(:,2);
    
    v_demo = stats_demo(:,4);
    psi_demo = stats_demo(:,3);
    
    % v = (psi_demo + atan((lr.*tan(delta_demo))/(lf + lr)))*180/pi;
    vx = v_demo.*cos(psi_demo + atan((lr.*tan(delta_demo))/(lf + lr)));
    vy = v_demo.*sin(psi_demo + atan((lr.*tan(delta_demo))/(lf + lr)));
    
    % average acceleration
    ax = (vx(3:end)-vx(1:end-2))/0.4;
    ay = (vy(3:end)-vy(1:end-2))/0.4;

    s = size(ax);
    rx = rx(2:s(1)+1);
    ry = ry(2:s(1)+1);
    vx = vx(2:s(1)+1);
    vy = vy(2:s(1)+1);
    t = 0:0.2:(s-1)*0.2;
    path_name = 'IOC\data_demo\';
    if rp==70
        data_demo70 = [t;rx';ry';vx';vy';ax';ay'];
        state_environment70 = (states_vehicles{1}(2:end-2,1:4))';    
        save([path_name,'data_demo70.mat'],'data_demo70');
        save([path_name,'state_environment70.mat'],'state_environment70');
    elseif rp==80
        data_demo80 = [t;rx';ry';vx';vy';ax';ay'];
        state_environment80 = (states_vehicles{1}(2:end-2,1:4))';    
        save([path_name,'data_demo80.mat'],'data_demo80');
        save([path_name,'state_environment80.mat'],'state_environment80');
    elseif rp==90
        data_demo90 = [t;rx';ry';vx';vy';ax';ay'];
        state_environment90 = (states_vehicles{1}(2:end-2,1:4))';    
        save([path_name,'data_demo90.mat'],'data_demo90');
        save([path_name,'state_environment90.mat'],'state_environment90');
    end
end








