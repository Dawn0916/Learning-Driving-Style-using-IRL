function printClosedloopData(mpciter, u, x, t_Elapsed)
    
%     global iterations;
%     global id_vehicle
%     
%     fprintf('%3d %3d  | %+11.6f %+11.6f %+6.3f %+6.3f %+6.3f  %+6.3f  %+6.3f', id_vehicle, iterations(end,:), ...
%             u(1), u(2), x(1), x(2), x(3), x(4) ,t_Elapsed);
end