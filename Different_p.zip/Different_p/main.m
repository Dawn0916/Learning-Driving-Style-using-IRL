% Compare the difference under different risk parameters
clc;
clear all;
addpath("IOC\");
addpath("SMPC\");
%% set the risk parameter value
risk_parameter = 70;
% risk_parameter = 90;
% %% gengrate the demonstration
% SMPC(risk_parameter);
%% do Inverse Optimal Control
data_plot=IOC(risk_parameter);