function cost_function = cost_function(n,T,fq,environment,theta,start,conntrol_points,time_end,n_feature,v_des)
%cost_function provides the framework for the cost function that the IOC needs to learn

%%   initializtion
    f_theta = zeros(n_feature,1);% initialize column vector f_theta, all = 0
    target_car = environment(1:2,:)';
    ego_car = zeros(round(time_end*fq+1),2); 
    for i = 1:n
        if i == 1
            cp_x0 = start(1:2:5,1);
            cp_y0 = start(2:2:6,1);
        else
            cp_x0 = conntrol_points(1:2:5,i-1);     % first control points used the start points
            cp_y0 = conntrol_points(2:2:6,i-1);
        end
        cp_xt = conntrol_points(1:2:5,i);           % following control points
        cp_yt = conntrol_points(2:2:6,i);
        if i == n % the end time is rounded
            T_end = time_end - T*(n-1); 
            % get coefficient 
            gx = subtrajectory_coefficient(T_end,[cp_x0;cp_xt]);
            gy = subtrajectory_coefficient(T_end,[cp_y0;cp_yt]);
            % get polynomial
            [rx,ry,vx,vy,ax,ay,jx,jy] = subtrajectory_polynomial(gx,gy);
            % calculate feature values
            f_theta = feature_functions(f_theta,rx,ry,vx,vy,ax,ay,jx,jy,T_end,fq,environment,T*fq*(i-1)+1,v_des,i);
        else% normal time interval
            gx = subtrajectory_coefficient(T,[cp_x0;cp_xt]);
            gy = subtrajectory_coefficient(T,[cp_y0;cp_yt]);
            [rx,ry,vx,vy,ax,ay,jx,jy] = subtrajectory_polynomial(gx,gy);
            f_theta = feature_functions(f_theta,rx,ry,vx,vy,ax,ay,jx,jy,T,fq,environment,T*fq*(i-1)+1,v_des,i);
        end
    end
    cost_function = (theta')*f_theta;
end


