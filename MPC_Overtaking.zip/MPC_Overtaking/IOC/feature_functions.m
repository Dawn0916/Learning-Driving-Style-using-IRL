function f = feature_functions(f, rx,ry,vx,vy,ax,ay,jx,jy,T,fq,environment,n0,v_des,i)
%feature_functions define the features we select and use for IOC

%% feature calculation
    % 1.feature:Acceleration
    func_fa = @(x) ax(x).^2 ;
    f(1) = f(1) + integral(func_fa,0,T);
    
    % 2.feature:Normal Acceleration
    func_fan = @(x) ay(x).^2;
    f(2) = f(2) + integral(func_fan,0,T);

    % 3.feature: Desired Speed
    func_fv = @(x) abs(v_des - vx(x));
    f(3) = f(3) + integral(func_fv,0,T);

    % 4.feature: Desired Lane
    lane = 13.125;
    func_fl3 = @(x) abs(lane-ry(x));
    f(4) = f(4) + integral(func_fl3,0,T,'ArrayValued',true);

    % 5.feature: Starting Lane
    if i == 1 
        func_fbegin = @(x) 10*abs(ry(x)-7.875);
        f(5) = f(5) + integral(func_fbegin,0,0.5,'ArrayValued',true);
    end

    % 6.feature: End Lane
    if i == 3
        func_fend = @(x) 10*abs(ry(x)-13.125);
        f(6) = f(6) + integral(func_fend,T-1,T,'ArrayValued',true);
    end
end