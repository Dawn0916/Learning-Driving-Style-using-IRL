function feature = get_feature(n,T,fq,environment,start,control_points,time_end,n_traj,n_feature,v_des)
%get_feature function is used to calculate the empirical feature and the approximated expected feature

%%   initializtion
    feature = zeros(n_feature,n_traj);
    target_car = environment(1:2,:)';
    ego_car = zeros(round(time_end*fq+1),2);
%%   calculate the feature values in cost function
    % select control points
    for j = 1:n_traj    
        for i = 1:n
            if i == 1
                x0 = start(6*(j-1)+1:2:6*(j-1)+5,1);
                y0 = start(6*(j-1)+2:2:6*(j-1)+6,1);              
 
            else
                x0 = control_points(6*(j-1)+1:2:6*(j-1)+5,i-1);     % first control points used the start points
                y0 = control_points(6*(j-1)+2:2:6*(j-1)+6,i-1);
            end           
            xt = control_points(6*(j-1)+1:2:6*(j-1)+5,i);           % following control points
            yt = control_points(6*(j-1)+2:2:6*(j-1)+6,i);        
            x = [x0;xt];
            y = [y0;yt];

            if i == n % the end time is rounded
                T_end = time_end - T*(n-1);
                % get coefficient
                gx = subtrajectory_coefficient(T_end,x);
                gy = subtrajectory_coefficient(T_end,y);
                % get polynomial
                [rx,ry,vx,vy,ax,ay,jx,jy] = subtrajectory_polynomial(gx,gy);
                % calculate feature values
                feature(:,j) = feature_functions(feature(:,j),rx,ry,vx,vy,ax,ay,jx,jy,T_end,fq,environment,T*fq*(i-1)+1,v_des,i);
            else% normal time interval
                gx = subtrajectory_coefficient(T,x);
                gy = subtrajectory_coefficient(T,y);    
                [rx,ry,vx,vy,ax,ay,jx,jy] = subtrajectory_polynomial(gx,gy);
                feature(:,j) = feature_functions(feature(:,j),rx,ry,vx,vy,ax,ay,jx,jy,T,fq,environment,T*fq*(i-1)+1,v_des,i); 
            end
        end
    end
    feature = mean(feature,2);
end

