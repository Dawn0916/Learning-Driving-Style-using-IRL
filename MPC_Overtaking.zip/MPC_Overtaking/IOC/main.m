clc;
clear all;
%% load the data from demonstrations
load('data_demo\data_demo60.mat');
load('data_demo\state_environment60.mat');
data_demo = data_demo60(2:7,3:30);
state_environment = state_environment60(:,3:30);
v_des = 35;             % desired speed used for feature
time_interval = 2;      % T=2s
frequency = 5;          % f=5Hz 
n_feature = 10;          % number of the features
[num_control_points,variables_start,variables_demo,time_end,n_trajectories] = manage_data(data_demo,time_interval,frequency);
% data for plotting the first demonstrated trajectory
data_plot = data_to_visualize(time_interval,frequency,[variables_start(1:6,:) variables_demo(1:6,:)],num_control_points,time_end);
%% step 1.Compute the empirical feature vector averaged over all demonstrations
empirical_feature = get_feature(num_control_points,time_interval,frequency,state_environment,variables_start,variables_demo,time_end,n_trajectories,n_feature,v_des);
%% step 2.Initialize the weight vector θ.
theta = ones(n_feature,1);
%% step 3.1 For each demonstrated trajectory, fix the environment state 
% including position,velocity and acceleration at the start, lane information and the state of nearby vehicles. 
% initialize trajectory for the lower level optimization problem
variables_init = prepare_variables(num_control_points,variables_start,state_environment,time_interval,frequency,n_trajectories);
lr=0.01;                % learning rate
cost = [0];             % upper level cost
iter = [0];             % number of iterations 
optimized_trajectories = [];
for i = 1:50
    for j = 1:n_trajectories  
%% step 3.2 optimize the free parameters of these trajectories with respect to the cost function θ^T*f(r).  
        obj = @(variables) cost_function(num_control_points,time_interval,frequency,state_environment,theta,variables_start(6*(j-1)+1:6*(j-1)+6,1),variables,time_end,n_feature,v_des);
        options = optimoptions('fminunc','Display','iter','Algorithm','quasi-newton');
        [x,fval] = fminunc(obj,variables_init(6*(j-1)+1:6*(j-1)+6,:),options);
    end
    % plot the optimized trajectory of the first demonstration every 5 iteration
    if mod(i,5) == 1 && i <= 11
        data_plot(end+1:end+6,:) = data_to_visualize(time_interval,frequency,[variables_start(1:6,:) x],num_control_points,time_end);    
    end
%% step 4. Compute the approximated expected feature values by evaluating the feature functions for all optimized trajectories
    expected_feature = get_feature(num_control_points,time_interval,frequency,state_environment,variables_start,x,time_end,n_trajectories,n_feature,v_des);
%% step 5. The gradient for the optimization 
    gradient = expected_feature - empirical_feature;  
    % upper level cost function 
    cost(end+1) = norm(gradient);
    iter(end+1) = i;
%% step 6. Updeta θ and Repeat from step 3 until convergence.  
    if abs(cost(end-1) - cost(end)) < 0.01        
        break
    end
    % update the weight vector
    theta = theta + lr*gradient; 
end
data_plot(end+1:end+6,:) = data_to_visualize(time_interval,frequency,[variables_start(1:6,:) x(1:6,:)],num_control_points,time_end);
%% plot the trajectories and upper lever cost function to check the convergence
plot_trajectories(iter,cost,data_plot,i,time_end)




        
