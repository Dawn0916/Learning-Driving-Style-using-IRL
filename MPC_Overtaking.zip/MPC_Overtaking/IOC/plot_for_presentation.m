clear all
close all
%% Load Positions information
%%% Car 1
car1=load('data_demo\data_demo60.mat');
%%% Car 2
car2=load('data_demo\state_environment60.mat');
%% Change struct to cell
%%% Car 1
Positions_car1_1=struct2cell(car1);
%%% Car 2
Positions_car2_1=struct2cell(car2);
%% Change cell to vector
%%% Car 1
PositionsCar1_1=Positions_car1_1{1};
%%% Car 2
PositionsCar2_1=Positions_car2_1{1};
%% Calculate average trajectories for each risk-parameters pair
%%% Car 1
Ave_PositionsCar1_1_x=PositionsCar1_1(2,3:33)';
Ave_PositionsCar1_1_y=PositionsCar1_1(3,3:33)';

%%% Car 2
Ave_PositionsCar2_1_x=PositionsCar2_1(1,3:33)';
Ave_PositionsCar2_1_y=PositionsCar2_1(2,3:33)';
%% Figures settings
fontsize_labels=16;
colors_vehicles=hsv(3);
w_lane=5.25;
l = 5;
b = 2;
x_count_start=0;
x_count_end=270;
%% trajectory described by fifth order Polynomial 
data_demo = PositionsCar1_1(2:7,3:33);
state_environment = PositionsCar2_1(:,3:33);
time_interval = 2; % T=2s
frequency = 5; % f=5Hz 
[num_control_points,variables_start,variables_demo,time_end,n_trajectories] = manage_data(data_demo,time_interval,frequency);
ego_car = [];
for j = 1:n_trajectories 
    for i = 1:num_control_points
        if i == 1
        x0 = variables_start(6*(j-1)+1:2:6*(j-1)+5,1);
        y0 = variables_start(6*(j-1)+2:2:6*(j-1)+6,1);
        else
        x0 = variables_demo(6*(j-1)+1:2:6*(j-1)+5,i-1);
        y0 = variables_demo(6*(j-1)+2:2:6*(j-1)+6,i-1);
        end 
        xt = variables_demo(6*(j-1)+1:2:6*(j-1)+5,i);
        yt = variables_demo(6*(j-1)+2:2:6*(j-1)+6,i);
        x = [x0;xt];
        y = [y0;yt];

        if i == num_control_points
            T_end = time_end - time_interval*(num_control_points-1);
            gx = subtrajectory_coefficient(T_end,x);
            gy = subtrajectory_coefficient(T_end,y);
            [rx,ry,vx,vy,ax,ay,jx,jy] = subtrajectory_polynomial(gx,gy);
            for t_mpc = 0:0.2:T_end
                ego_car = [ego_car;rx(t_mpc) ry(t_mpc)];
            end
        else
            gx = subtrajectory_coefficient(time_interval,x);
            gy = subtrajectory_coefficient(time_interval,y);    
            [rx,ry,vx,vy,ax,ay,jx,jy] = subtrajectory_polynomial(gx,gy);
            for t_mpc = 0:0.2:time_interval-0.2
                ego_car = [ego_car;rx(t_mpc) ry(t_mpc)];
            end
        end
    end
end
figure(1)
subplot(2,1,2)
plot([0 x_count_end],[0 0],'k-', 'LineWidth', 1.5)
hold on
plot([0 x_count_end],[w_lane w_lane],'k--', 'LineWidth', 1.5)
hold on
plot([0 x_count_end],[2*w_lane 2*w_lane],'k--', 'LineWidth', 1.5)
hold on
plot([0 x_count_end],[3*w_lane 3*w_lane],'k-', 'LineWidth', 1.5)
hold on
p2(1) = plot(Ave_PositionsCar2_1_x,Ave_PositionsCar2_1_y,'--r','LineWidth',3);
hold on
p2(3) = plot(ego_car(1:11,1),ego_car(1:11,2),'Color',[1 1 0],'linewidth',5);
hold on
p2(4) = plot(ego_car(11:21,1),ego_car(11:21,2),'Color',[0 1 1],'linewidth',5);
hold on
p2(5) = plot(ego_car(21:31,1),ego_car(21:31,2),'Color',	[0 1 0],'linewidth',5);
hold on
p2(2) = plot(Ave_PositionsCar1_1_x,Ave_PositionsCar1_1_y,'--k','LineWidth',3);
hold on
plot(ego_car(1,1),ego_car(1,2),".",'Color',[0 0 1],'MarkerSize',40);
hold on
plot(ego_car(11,1),ego_car(11,2),".",'Color',[0 0 1],'MarkerSize',40);
hold on
plot(ego_car(21,1),ego_car(21,2),".",'Color',[0 0 1],'MarkerSize',40);
hold on
plot(ego_car(31,1),ego_car(31,2),".",'Color',[0 0 1],'MarkerSize',40);
hold on
xlabel('$x$(m)','interpreter','latex','FontSize',20);
ylabel('$y$(m)','interpreter','latex','FontSize',20);
title('Trajectory represented by control points and 5th order polynomial','FontName','Times New Roman','FontSize',20)
legend(p2,'original TV trajectory ','original EV trajectory ','1st quintic polynomial subspline','2nd quintic polynomial subspline','3rd quintic polynomial subspline','FontName','Times New Roman','FontSize',15,'FontWeight','normal','Location','southeast');
axis([x_count_start,x_count_end,-1,3*w_lane+1]);
set(gca,'linewidth',1.5,'FontSize',15);