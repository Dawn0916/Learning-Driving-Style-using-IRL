function [g] = subtrajectory_coefficient(T,control_point)
%subtrajectory_coefficient function calculate the coefficients of the 5th order polynomial

%% six boundary conditions
p0 = control_point(1,1);
v0 = control_point(2,1);
a0 = control_point(3,1);
pt = control_point(4,1);
vt = control_point(5,1);
at = control_point(6,1);
%% six euqtions to calculate the coefficients
g0=p0;
g1=v0;
g2=a0/2;
g3=(-10*p0-6*v0*T-3/2*a0*T^2+10*pt-4*vt*T+1/2*at*T^2)/(T^3);
g4=(15*p0+8*v0*T+3/2*a0*T^2-15*pt+7*vt*T-at*T^2)/(T^4);
g5=(-6*p0-3*v0*T-1/2*a0*T^2+6*pt-3*vt*T+1/2*at*T^2)/(T^5);
g = [g0 g1 g2 g3 g4 g5];
end
