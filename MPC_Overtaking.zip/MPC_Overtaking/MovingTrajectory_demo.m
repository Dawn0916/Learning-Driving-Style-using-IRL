function MovingTrajectory_demo(states_vehicles,params_lane,predicted_states_EV,colors_vehicles)
% params_lane;                 % parameters of lane [Lane_width,Lane_length]
% predicted_states_EV;         % predicted_states of all ego vehicles
% assumeded_states_TV;         % assumed states of all target vehicles
% colors_vehicles;             % color of vehicles
% iterations;                  % tracking of the time skips

hold off

w_lane=params_lane(1);
fontsize_labels=12;
% figure
set(gcf,'Units','normalized','OuterPosition',[0.0 0.3 0.99 0.35]);
%% Plot the predicted trajectory of ego vehicle 2
% predicted_states of ego vehicle 2
predicted_positions_x_EV=predicted_states_EV{2}(:,1);
predicted_positions_y_EV=predicted_states_EV{2}(:,2);

% plot trajectory of ego vehicle 2
position_x_EV=states_vehicles{2}(:,1);
position_y_EV=states_vehicles{2}(:,2);
plot(position_x_EV', position_y_EV','o','linewidth',3,'color',colors_vehicles(2,:));
hold on
plot(predicted_positions_x_EV', predicted_positions_y_EV','-.','linewidth',1,'color',colors_vehicles(2,:));
hold on
%% Plot the trajectory of  vehicle 1
states_vehicle_TV=states_vehicles{1}(end,:);
position_x_TV=states_vehicle_TV(1);   % The center of the ellipse should be the assumed TV center
position_y_TV=states_vehicle_TV(2);

Ellipse_x1=position_x_TV-20;
Ellipse_x2=position_x_TV+20;
Ellipse_y1=position_y_TV;
Ellipse_y2=position_y_TV;
%eccentricity = 0.97;
numPoints = 300; % Less for a coarser ellipse, more for a finer resolution.
% Make equations:
Ellipse_a = (1/2) * sqrt((Ellipse_x2 - Ellipse_x1) ^ 2 + (Ellipse_y2 - Ellipse_y1) ^ 2);
Ellipse_b = 3;
t = linspace(0, 2 * pi, numPoints); % Absolute angle parameter
X = Ellipse_a * cos(t);
Y = Ellipse_b * sin(t);
% Compute angles relative to (x1, y1).
angles = atan2(Ellipse_y2 - Ellipse_y1, Ellipse_x2 - Ellipse_x1);
Ellipse_x = (Ellipse_x1 + Ellipse_x2) / 2 + X * cos(angles) - Y * sin(angles);
Ellipse_y = (Ellipse_y1 + Ellipse_y2) / 2 + X * sin(angles) + Y * cos(angles);

% Plot ellipse
plot(Ellipse_x,Ellipse_y,'linewidth',1,'color',colors_vehicles(1,:));	
hold on
  
% plot trajectory of target vehicle 1
positions_x_TV=states_vehicles{1}(:,1);   % The center of the ellipse should be the assumed TV center
positions_y_TV=states_vehicles{1}(:,2);
plot(positions_x_TV', positions_y_TV','x','linewidth',3,'color',colors_vehicles(1,:));
hold on
%% Plot the assumeded trajectory of ego vehicle 3
%% figure setting
% start_x=position_x_EV-25;
% end_x=position_x_EV+55;
start_x = 0;
end_x = predicted_states_EV{2}(1,1)+100;
title(sprintf('Moving trajectories from the view of vehicle 2'),'interpreter','latex','FontSize',fontsize_labels)
axis([start_x end_x -1 16])
ylabel('$y$','interpreter','latex','FontSize',fontsize_labels)
xlabel('$x$','interpreter','latex','FontSize',fontsize_labels)
hold on
%% plot the lines between lanes
plot([start_x end_x], [0 0], '-k', 'LineWidth', 1.5);
hold on;
plot([start_x end_x], [w_lane w_lane], '--k','LineWidth', 1.5);
hold on;
plot([start_x end_x], [2*w_lane 2*w_lane], '--k', 'LineWidth', 1.5);
hold on;
plot([start_x end_x], [3*w_lane 3*w_lane], '-k', 'LineWidth', 1.5);
hold on;
end
