function convert_data(states_vehicles,control_vehicles)
    lr = 2;
    lf = 2;
    
    stats_demo = states_vehicles{2}(1:end-1,:);   
    a_demo = control_vehicles{2}(3:2:end-1,1);
    delta_demo = control_vehicles{2}(4:2:end,1);
    
    rx = stats_demo(:,1);
    ry = stats_demo(:,2);
    
    v_demo = stats_demo(:,4);
    psi_demo = stats_demo(:,3);
    
    % = (psi_demo + atan((lr.*tan(delta_demo))/(lf + lr)))*180/pi;
    vx = v_demo.*cos(psi_demo + atan((lr.*tan(delta_demo))/(lf + lr)));
    vy = v_demo.*sin(psi_demo + atan((lr.*tan(delta_demo))/(lf + lr)));
    
    ax = (vx(3:end)-vx(1:end-2))/0.4;
    ay = (vy(3:end)-vy(1:end-2))/0.4;

    % selected the lane change maneuvers.
%     ax = [ax(1);ax;ax(end)];
%     ay = [ay(1);ay;ay(end)];    
%     begin_selected = ry > 7.9;
%     end_selected = ry < 13.1;
%     select = begin_selected.*end_selected;  
%     for i = 1:length(select)-1
%         if select(i) < select(i+1)
%             begin_flag = i;
%         end
%         if select(i) > select(i+1)
%             end_flag = (i+1);
%         end
%     end
%     select(begin_flag) = 1;
%     select(end_flag) = 1;
%     select = select > 0;
%     rx = rx(select);
%     ry = ry(select);
%     vx = vx(select);
%     vy = vy(select);
%     ax = ax(select);
%     ay = ay(select);
%     t = 0:0.2:(size(rx)-1)*0.2;
%     state_environment = state_environment(:,select);

    s = size(ax);
    rx = rx(2:s(1)+1);
    ry = ry(2:s(1)+1);
    vx = vx(2:s(1)+1);
    vy = vy(2:s(1)+1);
    t = 0:0.2:(s-1)*0.2;
    path_name = 'get_feature\data_demo\';
    data_demo60 = [t;rx';ry';vx';vy';ax';ay'];
    state_environment60 = (states_vehicles{1}(2:end-2,1:4))';    
    save([path_name,'data_demo60.mat'],'data_demo60');
    save([path_name,'state_environment60.mat'],'state_environment60');
end








